#include "SceneManager.h"
#include <string>

static const char* VS = R"(#version 330 core
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aCol;
uniform mat4 uMVP;
out vec3 vCol;
void main(){ vCol=aCol; gl_Position = uMVP * vec4(aPos,1.0); }
)";

static const char* FS = R"(#version 330 core
in vec3 vCol;
out vec4 FragColor;
void main(){ FragColor = vec4(vCol,1.0); }
)";

bool SceneManager::Init(int width, int height, std::string& outErr) {
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) { outErr = "GLEW init failed"; return false; }

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.08f, 0.09f, 0.12f, 1.0f);

    std::string err;
    if (!shader.LoadFromSource(VS, FS, err)) { outErr = err; return false; }

    meshes.CreateAll();
    Resize(width, height);
    return true;
}

void SceneManager::Resize(int width, int height) {
    glViewport(0, 0, width, height);
    proj = mat_perspective(45.0f * 3.1415926f / 180.0f, width > 0 ? (float)width / (float)height : 1.0f, 0.1f, 100.0f);
}

void SceneManager::Update(float dt) { rotY += dt * 0.5f; }

void SceneManager::Draw() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    shader.Use();
    // Plane (ground)
    Mat4 m = mat_identity();
    Mat4 vp = mat_mul(proj, cam.view());
    Mat4 mvp = mat_mul(vp, m);
    glUniformMatrix4fv(shader.GetUniform("uMVP"), 1, GL_FALSE, mvp.m);
    glBindVertexArray(meshes.plane.vao);
    glDrawArrays(GL_TRIANGLES, 0, meshes.plane.vertexCount);

    // Rotating cube
    m = mat_mul(mat_translate({ -1.2f,0.5f,0.0f }), mat_rotateY(rotY));
    mvp = mat_mul(vp, m);
    glUniformMatrix4fv(shader.GetUniform("uMVP"), 1, GL_FALSE, mvp.m);
    glBindVertexArray(meshes.cube.vao);
    glDrawArrays(GL_TRIANGLES, 0, meshes.cube.vertexCount);

    // Pyramid
    m = mat_mul(mat_translate({ 1.2f,0.0f,0.0f }), mat_scale({ 1,1,1 }));
    mvp = mat_mul(vp, m);
    glUniformMatrix4fv(shader.GetUniform("uMVP"), 1, GL_FALSE, mvp.m);
    glBindVertexArray(meshes.pyramid.vao);
    glDrawArrays(GL_TRIANGLES, 0, meshes.pyramid.vertexCount);

    glBindVertexArray(0);
}

void SceneManager::MoveForward(float s) {
    // forward vector from yaw/pitch (same as Camera::view logic)
    Vec3 f = { std::cos(cam.pitchRadians) * std::sin(cam.yawRadians),
               0.0f,
               std::cos(cam.pitchRadians) * std::cos(cam.yawRadians) * -1.0f };
    cam.pos = { cam.pos.x + f.x * s, cam.pos.y + f.y * s, cam.pos.z + f.z * s };
}
void SceneManager::MoveRight(float s) {
    Vec3 forward = { std::sin(cam.yawRadians), 0.0f, std::cos(cam.yawRadians) * -1.0f };
    Vec3 right = { forward.z, 0.0f, -forward.x };
    cam.pos = { cam.pos.x + right.x * s, cam.pos.y + right.y * s, cam.pos.z + right.z * s };
}
void SceneManager::MoveUp(float s) { cam.pos.y += s; }
void SceneManager::Yaw(float r) { cam.yawRadians += r; }
void SceneManager::Pitch(float r) { cam.pitchRadians += r; }
