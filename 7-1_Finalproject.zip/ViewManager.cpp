#include "ViewManager.h"
#include <cstdio>

static ViewManager* g_vm = nullptr;

bool ViewManager::CreateWindow(int w, int h, const char* title, std::string& outErr) {
    if (!glfwInit()) { outErr = "GLFW init failed"; return false; }
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    m_window = glfwCreateWindow(w, h, title, nullptr, nullptr);
    if (!m_window) { outErr = "GLFW window creation failed"; glfwTerminate(); return false; }
    glfwMakeContextCurrent(m_window);
    glfwSwapInterval(1);

    g_vm = this;
    glfwSetFramebufferSizeCallback(m_window, framebuffer_size_callback);
    glfwSetKeyCallback(m_window, key_callback);

    if (!m_scene.Init(w, h, outErr)) { return false; }

    m_prevTime = glfwGetTime();
    return true;
}

void ViewManager::MainLoop() {
    while (!glfwWindowShouldClose(m_window)) {
        double t = glfwGetTime();
        float dt = static_cast<float>(t - m_prevTime);
        m_prevTime = t;

        handleContinuousInput(dt);
        m_scene.Update(dt);
        m_scene.Draw();

        glfwSwapBuffers(m_window);
        glfwPollEvents();
    }
}

void ViewManager::Destroy() {
    m_scene = SceneManager(); // let GL objects go out of scope (or add explicit destroy methods)
    if (m_window) { glfwDestroyWindow(m_window); m_window = nullptr; }
    glfwTerminate();
}

void ViewManager::framebuffer_size_callback(GLFWwindow*, int w, int h) {
    if (g_vm) g_vm->m_scene.Resize(w, h);
}
void ViewManager::key_callback(GLFWwindow* win, int key, int, int action, int) {
    if (!g_vm) return;
    if (key >= 0 && key < 512) {
        if (action == GLFW_PRESS) g_vm->m_keys[key] = true;
        else if (action == GLFW_RELEASE) g_vm->m_keys[key] = false;
    }
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) glfwSetWindowShouldClose(win, true);
}
void ViewManager::handleContinuousInput(float dt) {
    const float move = 3.0f * dt;
    const float rot = 1.5f * dt;
    if (m_keys[GLFW_KEY_W]) m_scene.MoveForward(+move);
    if (m_keys[GLFW_KEY_S]) m_scene.MoveForward(-move);
    if (m_keys[GLFW_KEY_A]) m_scene.MoveRight(-move);
    if (m_keys[GLFW_KEY_D]) m_scene.MoveRight(+move);
    if (m_keys[GLFW_KEY_Q]) m_scene.MoveUp(-move);
    if (m_keys[GLFW_KEY_E]) m_scene.MoveUp(+move);

    if (m_keys[GLFW_KEY_LEFT])  m_scene.Yaw(+rot);
    if (m_keys[GLFW_KEY_RIGHT]) m_scene.Yaw(-rot);
    if (m_keys[GLFW_KEY_UP])    m_scene.Pitch(+rot * 0.5f);
    if (m_keys[GLFW_KEY_DOWN])  m_scene.Pitch(-rot * 0.5f);
}
