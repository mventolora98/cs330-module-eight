#define GLEW_STATIC
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include "ViewManager.h"

int main() {
    std::string err;
    ViewManager vm;
    if (!vm.CreateWindow(1280, 720, "CS330 Final Project (GLEW + GLFW)", err)) {
        std::cerr << "Init error: " << err << std::endl;
        return 1;
    }
    vm.MainLoop();
    vm.Destroy();
    return 0;
}
