#pragma once
#include <GL/glew.h>

struct Mesh {
    GLuint vao = 0, vbo = 0;
    GLsizei vertexCount = 0;
    void Destroy();
};

struct ShapeMeshes {
    Mesh cube;
    Mesh pyramid;
    Mesh plane;
    void CreateAll();
    void DestroyAll();
};
