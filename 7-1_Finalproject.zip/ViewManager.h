#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <string>
#include "SceneManager.h"

class ViewManager {
public:
    bool CreateWindow(int w, int h, const char* title, std::string& outErr);
    void MainLoop();
    void Destroy();

private:
    static void framebuffer_size_callback(GLFWwindow* win, int width, int height);
    static void key_callback(GLFWwindow* win, int key, int sc, int action, int mods);
    void handleContinuousInput(float dt);

    GLFWwindow* m_window = nullptr;
    SceneManager m_scene;
    double m_prevTime = 0.0;
    bool m_keys[512]{};
};
