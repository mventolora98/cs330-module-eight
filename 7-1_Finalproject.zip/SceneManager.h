#pragma once
#include "ShapeMeshes.h"
#include "ShaderManager.h"
#include "camera.h"

class SceneManager {
public:
    bool Init(int width, int height, std::string& outErr);
    void Resize(int width, int height);
    void Update(float dt);
    void Draw();

    // control
    void MoveForward(float s);
    void MoveRight(float s);
    void MoveUp(float s);
    void Yaw(float r);
    void Pitch(float r);

private:
    ShapeMeshes meshes;
    ShaderManager shader;
    Camera cam;
    Mat4 proj{};
    float rotY = 0.f;
};
