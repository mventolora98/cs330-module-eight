#pragma once
#include <GL/glew.h>
#include <GLFW/glfw3.h>

// Minimal 3D vector and 4x4 matrix (column-major)
struct Vec3 { float x, y, z; };
struct Mat4 { float m[16]; };

Mat4 mat_identity();
Mat4 mat_mul(const Mat4& a, const Mat4& b);
Mat4 mat_translate(const Vec3& t);
Mat4 mat_scale(const Vec3& s);
Mat4 mat_rotateY(float radians);
Mat4 mat_perspective(float fovyRadians, float aspect, float znear, float zfar);
Mat4 mat_lookAt(const Vec3& eye, const Vec3& center, const Vec3& up);

struct Camera {
    Vec3 pos{ 0.0f, 1.5f, 5.0f };
    float yawRadians = 0.0f;
    float pitchRadians = 0.0f;

    Mat4 view() const;
};
