#include "camera.h"
#include <cmath>

static Vec3 v3(float x, float y, float z) { return { x,y,z }; }
static Vec3 add(const Vec3& a, const Vec3& b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static Vec3 sub(const Vec3& a, const Vec3& b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static Vec3 muls(const Vec3& a, float s) { return v3(a.x * s, a.y * s, a.z * s); }
static float dot(const Vec3& a, const Vec3& b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static Vec3 cross(const Vec3& a, const Vec3& b) {
    return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x);
}
static Vec3 norm(const Vec3& a) {
    float d = std::sqrt(dot(a, a)); return d > 0 ? v3(a.x / d, a.y / d, a.z / d) : v3(0, 0, 0);
}

Mat4 mat_identity() { Mat4 r{}; for (int i = 0; i < 16; ++i) r.m[i] = (i % 5 == 0) ? 1.f : 0.f; return r; }
Mat4 mat_mul(const Mat4& A, const Mat4& B) {
    Mat4 R{};
    for (int c = 0; c < 4; ++c) for (int r = 0; r < 4; ++r) {
        R.m[c * 4 + r] = A.m[0 * 4 + r] * B.m[c * 4 + 0] + A.m[1 * 4 + r] * B.m[c * 4 + 1] + A.m[2 * 4 + r] * B.m[c * 4 + 2] + A.m[3 * 4 + r] * B.m[c * 4 + 3];
    } return R;
}
Mat4 mat_translate(const Vec3& t) { Mat4 r = mat_identity(); r.m[12] = t.x; r.m[13] = t.y; r.m[14] = t.z; return r; }
Mat4 mat_scale(const Vec3& s) { Mat4 r{}; r.m[0] = s.x; r.m[5] = s.y; r.m[10] = s.z; r.m[15] = 1; return r; }
Mat4 mat_rotateY(float a) { Mat4 r = mat_identity(); float c = std::cos(a), s = std::sin(a); r.m[0] = c; r.m[2] = s; r.m[8] = -s; r.m[10] = c; return r; }
Mat4 mat_perspective(float fovy, float aspect, float znear, float zfar) {
    float f = 1.0f / std::tan(fovy * 0.5f);
    Mat4 r{}; r.m[0] = f / aspect; r.m[5] = f; r.m[10] = (zfar + znear) / (znear - zfar); r.m[11] = -1.f; r.m[14] = (2 * zfar * znear) / (znear - zfar);
    return r;
}
Mat4 mat_lookAt(const Vec3& eye, const Vec3& center, const Vec3& up) {
    Vec3 f = norm(sub(center, eye));
    Vec3 s = norm(cross(f, up));
    Vec3 u = cross(s, f);
    Mat4 r = mat_identity();
    r.m[0] = s.x; r.m[4] = s.y; r.m[8] = s.z;
    r.m[1] = u.x; r.m[5] = u.y; r.m[9] = u.z;
    r.m[2] = -f.x; r.m[6] = -f.y; r.m[10] = -f.z;
    r.m[12] = -dot(s, eye); r.m[13] = -dot(u, eye); r.m[14] = dot(f, eye);
    return r;
}

Mat4 Camera::view() const {
    Vec3 forward = { std::cos(pitchRadians) * std::sin(yawRadians),
                     std::sin(pitchRadians),
                     std::cos(pitchRadians) * std::cos(yawRadians) * -1.0f };
    Vec3 center = add(pos, forward);
    return mat_lookAt(pos, center, v3(0, 1, 0));
}
