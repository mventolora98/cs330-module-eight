#pragma once
#include <GL/glew.h>
#include <string>

class ShaderManager {
public:
    bool LoadFromSource(const std::string& vsSrc, const std::string& fsSrc, std::string& outErr);
    void Use() const;
    GLint GetUniform(const char* name) const;
    GLuint Program() const { return m_programID; }
    void Destroy();

private:
    static bool Compile(GLuint shader, const std::string& src, std::string& err);
    static bool Link(GLuint program, std::string& err);
    GLuint m_programID = 0;
};
